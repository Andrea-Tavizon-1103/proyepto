<?php
include 'db.php'; // Incluye la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica que los campos no estén vacíos
    if (!isset($_POST['usuario'], $_POST['email'], $_POST['password'])) {
        die("Error: Faltan campos obligatorios.");
    }

    $usuario = $_POST['usuario'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encripta la contraseña

    // Prepara la consulta SQL para insertar el nuevo usuario
    $sql = "INSERT INTO users (usuario, email, password) VALUES (?, ?, ?)";
    $stmt = $db->prepare($sql);

    // Verifica si la preparación de la consulta fue exitosa
    if (!$stmt) {
        die("Error en la preparación de la consulta: " . $db->error);
    }

    // Vincula los parámetros y ejecuta la consulta
    $stmt->bind_param("sss", $usuario, $email, $password);

    if ($stmt->execute()) {
        echo "Usuario registrado exitosamente.";
    } else {
        echo "Error al registrar el usuario: " . $stmt->error;
    }

    // Cierra la consulta y la conexión
    $stmt->close();
    $db->close();
}
?>
