<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccesTel</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="Sstyle.css">
</head>
<body>

<header>
    <nav>
    <div class="logo">
            <a href="index.php">
                <img src="img/apple.png" height="50" alt="Logo de AccesTel">
            </a>
        </div>
        <nav class="navbar">
            <div class="container">
                <div class="navbar-header">
                    <!--<button class="navbar-toggler" data-toggle="open-navbar1">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>-->
                </div>

                <div class="navbar-menu" id="open-navbar1">
                    <ul class="navbar-nav">
                        <li class="active"><a href="index.php">Inicio</a></li>
                        <li class="navbar-dropdown">
                            <a href="#" class="dropdown-toggler" data-dropdown="my-dropdown-id">
                                Categorias <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown" id="my-dropdown-id">
                                <li><a href="audi.php">Audifonos</a></li>
                                <li><a href="carga.php">Cargadores</a></li>
                                <li><a href="fundas.php">Fundas</a></li>
                                <li><a href="otro.php">Otros</a></li>
                            </ul>
                        </li>
                        <li><a href="contacto.php">Contacto</a></li>
                        <a href="cart.php">
                <img src="img/bolsa.png" alt="Carrito de compras" height="35">
            </a>
                    </ul>
                </div>
            </div>
        </nav>
    </nav>            
</header>
<div class="container books-container">
<?php
session_start(); // Asegúrate de iniciar la sesión para manejar usuarios

$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_de_datos = "accestel";

// Establecer conexión a la base de datos
$conexion = new mysqli($host, $usuario, $contrasena, $base_de_datos);

// Comprobar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Realizar la consulta con filtro por categoría
$sentencia = "SELECT * FROM productos WHERE categoria = 'proteccion'";
$resultado = $conexion->query($sentencia);

// Verificar si hay productos disponibles
if ($resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        echo "<div class='book'> 
                <div class='book-image-container'>
                    <img src='" . htmlspecialchars($row["imagen"]) . "' alt='" . htmlspecialchars($row["nombre"]) . "' class='book-image'>
                </div>
                <div class='book-info'>
                    <h2 class='book-title'>" . htmlspecialchars($row["nombre"]) . "</h2>
                    <p><strong>Descripción:</strong> " . htmlspecialchars($row["descripcion"]) . "</p>
                    <p><strong>Precio:</strong> $" . htmlspecialchars($row["precio"]) . "</p>";
        
        // Verificar si el usuario ha iniciado sesión
        if (isset($_SESSION['login_user'])) {
            echo "<form action='cart.php' method='post'>
                      <input type='hidden' name='id' value='" . htmlspecialchars($row["id"]) . "'>
                      <input type='hidden' name='name' value='" . htmlspecialchars($row["nombre"]) . "'>
                      <input type='hidden' name='price' value='" . htmlspecialchars($row["precio"]) . "'>
                      <button type='submit' class='buy-button'>Comprar</button>
                  </form>";
        } else {
            echo "<button class='buy-button' onclick='showAlert()'>Comprar</button>";
        }
        
        echo "</div>
              </div>";
    }
} else {
    echo "<p>No hay productos disponibles.</p>";
}

// Cerrar conexión
$conexion->close();
?>

<script>
    function showAlert() {
        alert("Debe iniciar sesión para agregar productos al carrito.");
    }
</script>

    

</div>
</body>
</html>