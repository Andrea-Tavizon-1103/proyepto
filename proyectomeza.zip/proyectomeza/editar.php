<?php
if (!isset($_GET["id"])) {
    exit("¡No se proporcionó el ID del producto!");
}
$ID_Producto = $_GET["id"];
include_once "db.php";

$sentencia = $db->prepare("SELECT * FROM productos WHERE id = ?");
$sentencia->bind_param("i", $ID_Producto);
$sentencia->execute();
$resultado = $sentencia->get_result();

if ($resultado->num_rows === 0) {
    exit("¡No existe un producto con ese ID!");
}

$producto = $resultado->fetch_object();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="styles.css?v=1.0">  <!-- Asegúrate de que esta ruta sea correcta -->
</head>
<body>

<div class="col-xs-12">
    <h1>Editar producto con el ID <?php echo $producto->id; ?></h1>
    <form method="post" action="guardarDatosEditados.php" enctype="multipart/form-data">
        <input type="hidden" name="ID_Productos" value="<?php echo $producto->id; ?>">

        <div class="form-group">
            <label for="name">Nombre:</label>
            <input type="text" name="name" class="form-control" value="<?php echo $producto->Nombre; ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Descripción:</label>
            <textarea name="description" class="form-control" required><?php echo $producto->Descripcion; ?></textarea>
        </div>

        <div class="form-group">
            <label for="price">Precio:</label>
            <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $producto->Precio; ?>" required>
        </div>

        <div class="form-group">
            <label for="imagen">Imagen actual:</label>
            <div class="current-image-container">
                <?php if (!empty($producto->Imagen)): ?>
                    <img src="<?php echo $producto->Imagen; ?>" width="100" height="100" alt="Imagen actual">
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label for="imagen">Nueva Imagen:</label>
            <input type="file" name="imagen" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <a href="listar.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

</body>
</html>
