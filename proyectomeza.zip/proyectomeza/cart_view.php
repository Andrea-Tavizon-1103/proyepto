<?php
session_start();

if (isset($_POST['vaciar_carrito'])) {
    unset($_SESSION['cart']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="stylesS.css">
    <link rel="stylesheet" href="stylesCar.css">
</head>
<body>
    <header>
        <div class="container">
            <img class="imag" src="images/x/logo.png" alt="">
            <div class="titulo">accesTel</div>
        </div>
        <hr size="2" width="99.9%" color="000">
    </header>

    <div class="contenedor">
        <h1>Carrito de Compras</h1>
        <?php
        if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
            $subtotal = 0;
            foreach ($_SESSION['cart'] as $key => $item) {
                // Verificar claves existentes
                $name = isset($item['name']) ? $item['name'] : 'Sin nombre';
                $descripcion = isset($item['descripcion']) ? $item['descripcion'] : 'Sin descripción';
                $price = isset($item['price']) ? $item['price'] : 0;
                $quantity = isset($item['quantity']) ? $item['quantity'] : 0;

                // Calcular subtotal
                $subtotal += $price * $quantity;

                echo "<div class='cart-item'>
                        <span><strong>Producto:</strong> $name (x$quantity)</span>
                        <span><strong>Descripción:</strong> $descripcion</span>
                        <span><strong>Precio:</strong> \$$price</span>
                        <button class='delete-btn' onclick='removeFromCart($key)'>Eliminar</button>
                      </div>";
            }
            echo "<h2>Subtotal: \$$subtotal</h2>";
        } else {
            echo "<h3>Tu carrito está vacío.</h3>";
        }
        ?>
        <a href="checkout.php" class="button-cart">Finalizar compra</a>
        <a href="catalogo.php" class="button-cart">Continuar comprando</a>
        <form action="" method="post">
            <button type="submit" name="vaciar_carrito" class="button-cart">Vaciar Carrito</button>
        </form>
    </div>

    <script>
        function removeFromCart(index) {
            if (confirm("¿Estás seguro de eliminar este producto del carrito?")) {
                window.location.href = "remove_from_cart.php?index=" + index;
            }
        }
    </script>
</body>
</html>
