<?php
session_start(); // Asegúrate de iniciar o recuperar la sesión

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccesTel</title>
    <link rel="stylesheet" href="stylesS.css">
</head>
<body>

<header>
    <nav>
        <div class="logo">
            <a href="index.php">
                <img src="img/apple.png" height="50" alt="Logo de AccesTel">
            </a>
        </div>
        <nav class="navbar">
            <div class="container">
                <div class="navbar-header"></div>
                <div class="navbar-menu" id="open-navbar1">
                    <ul class="navbar-nav">
                        <li class="active"><a href="index.php">Inicio</a></li>
                        <li class="navbar-dropdown">
                            <a href="#" class="dropdown-toggler" data-dropdown="my-dropdown-id">
                                Categorías <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown" id="my-dropdown-id">
                                <li><a href="audi.php">Audífonos</a></li>
                                <li><a href="carga.php">Cargadores</a></li>
                                <li><a href="fundas.php">Fundas</a></li>
                                <li><a href="otro.php">Otros</a></li>
                            </ul>
                        </li>
                        <li><a href="contacto.php">Contacto</a></li>
                        <?php if (isset($_SESSION['login_user'])): ?>
                            <!-- Si el usuario está logueado, muestra el carrito y cerrar sesión -->
                            <li><a href="cart.php">
                                <img src="img/bolsa.png" alt="Carrito de compras" height="35">
                            </a></li>
                            <li><a href="logout.php">Cerrar sesión</a></li>
                        <?php else: ?>
                            <!-- Si no hay sesión activa, muestra iniciar sesión -->
                            <li><a href="iniciosesion.php">Iniciar sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </nav>            
</header>

<div class="carousel">
    <div class="list">
        <div class="item">
            <img src="img/carg.png">
            <div class="introduce">
                <div class="title"></div>
                <div class="topic">Cargador</div>
                <div class="des">
                    "Carga tu vida no tus preocupaciones"- Cargador rápido y eficiente
                </div>
                <button class="seeMore">VER MAS ↗️</button>
            </div>
            <div class="detail">
                <div class="title">Cargador </div>
                <div class="des">
                    Adaptador de corriente Tipo C de 20 W
                </div>
                <div class="specifications">
                    <div>
                        <p>Tiempo de uso</p>
                        <p>1 Hora</p>
                    </div>
                    <div>
                        <p>Puerto de carga</p>
                        <p>Tipo C-Lightning</p>
                    </div>
                    <div>
                        <p>Compatible</p>
                        <p>IPhone</p>
                    </div>
                    <div>
                        <p>Portabilidad</p>
                        <p>Compacto y ligero para facilitar el transporte.</p>
                    </div>
                    <div>
                        <p>Precio en stock</p>
                        <p>$549.00</p>
                    </div>
                </div>
                <a href ="carga.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
            </div>
        </div>

        <!-- Repite el bloque de cada item con sus respectivos cambios -->
        <div class="item">
            <img src="img/funda.png">
            <div class="introduce">
                <div class="title"></div>
                <div class="topic">Fundas</div>
                <div class="des">
                    "Estilo y seguridad en un solo paso"
                </div>
                <button class="seeMore">VER MAS ↗️</button>
            </div>
            <div class="detail">
                <div class="title">Fundas</div>
                <div class="des">
                    Funda de silicón con MagSafe 
                </div>
                <div class="specifications">
                    <div>
                        <p>Resistencia</p>
                        <p>Protección contra caídas de hasta 3 metros</p>
                    </div>
                    <div>
                        <p>Materiales</p>
                        <p>Fabricada con silicon de alta calidad</p>
                    </div>
                    <div>
                        <p>Diseño</p>
                        <p>Antideslizante</p>
                    </div>
                    <div>
                        <p>Compatible</p>
                        <p>Diseñada para iPhone</p>
                    </div>
                    <div>
                        <p>Precio en stock</p>
                        <p>$1,099.00</p>
                    </div>
                </div>
                <a href ="fundas.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
            </div>
        </div>

        <div class="item">
                <img src="img/carte.png">
                <div class="introduce">
                    <div class="title"></div>
                    <div class="topic">Cartera de FineWoven</div>
                    <div class="des">
                        "Lleva lo esencial, con estilo excepcional: la Cartera FineWoven de Apple, donde innovación y sostenibilidad se encuentran."
                    </div>
                    <button class="seeMore">VER MAS ↗️</button>
                </div>
                <div class="detail">
                    <div class="title">Cartera de FineWoven</div>
                    <div class="des">
                        Fabricada con FineWoven, un material innovador que combina durabilidad y elegancia con un menor impacto ambiental
                    </div>
                    <div class="specifications">
                        <div>
                            <p>Materiales</p>
                            <p>Material con un enfoque ecológico, diseñado para reducir la huella ambiental</p>
                        </div>
                        <div>
                            <p>Compatible</p>
                            <p>Compatible con MagSafe</p>
                        </div>
                        <div>
                            <p>Capacidad</p>
                            <p>Espacio para hasta 3 tarjetas esenciales</p>
                        </div>
                        <div>
                            <p>Colores</p>
                            <p>Disponible en tonos minimalistas como azul océano, gris humo y verde bosque</p>
                        </div>
                        <div>
                            <p>Precio</p>
                            <p>$1,399.00</p>
                        </div>
                    </div>
                    <a href ="otro.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
                </div>
            </div>
            <div class="item">
                <img src="img/max.png">
                <div class="introduce">
                    <div class="title"></div>
                    <div class="topic">AirPods Max</div>
                    <div class="des">
                        "Sonido de otro nivel, diseño que impresiona: descubre la perfección acústica con los AirPods Max de Apple."
                    </div>
                    <button class="seeMore">VER MAS ↗️</button>
                </div>
                <div class="detail">
                    <div class="title">AirPods Max</div>
                    <div class="des">
                        Auriculares de diadema con un acabado en aluminio anodizado, malla transpirable y almohadillas de espuma viscoelástica para máxima comodidad.
                    </div>
                    <div class="specifications">
                        <div>
                            <p>Tiempo de uso</p>
                            <p> Hasta 20 horas con funciones activadas</p>
                        </div>
                        <div>
                            <p>Puerto de carga</p>
                            <p>Lightning</p>
                        </div>
                        <div>
                            <p>Compatible</p>
                            <p>iPhone, iPad, Mac, Apple Watch, Apple TV</p>
                        </div>
                        <div>
                            <p>Bluetooth</p>
                            <p>5.0</p>
                        </div>
                        <div>
                            <p>Precio</p>
                            <p>$12,999.00</p>
                        </div>
                    </div>
                    <a href ="audi.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
                </div>
            </div>
            <div class="item">
                <img src="img/airpods.png">
                <div class="introduce">
                    <div class="title"></div>
                    <div class="topic">AirPods Pro</div>
                    <div class="des">
                        "Sumérgete en un sonido de calidad superior, con AirPods, tu música cobra vida."
                    </div>
                    <button class="seeMore">VER MAS ↗️</button>
                </div>
                <div class="detail">
                    <div class="title">AirPods Pro</div>
                    <div class="des">
                        Los AirPods ofrecen una conexión más rápida, estable y eficiente en términos de energía, junto con la compatibilidad optimizada dentro del ecosistema Apple.
                    </div>
                    <div class="specifications">
                        <div>
                            <p>Tiempo de uso</p>
                            <p>5 horas con una sola carga</p>
                        </div>
                        <div>
                            <p>Puerto de carga</p>
                            <p>Lightning</p>
                        </div>
                        <div>
                            <p>Compatible</p>
                            <p>iPhone, iPad, Mac, Apple Watch, Apple TV</p>
                        </div>
                        <div>
                            <p>Bluetooth</p>
                            <p>5.0</p>
                        </div>
                        <div>
                            <p>Precio</p>
                            <p>$5799.00</p>
                        </div>
                    </div>
                    <a href ="audi.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
                </div>
            </div>
            <div class="item">
                <img src="img/homep.png">
                <div class="introduce">
                    <div class="title"></div>
                    <div class="topic">Home Pod mini</div>
                    <div class="des">
                        "Controla tu hogar, sin salir de casa"
                    </div>
                    <button class="seeMore">VER MAS ↗️</button>
                </div>
                <div class="detail">
                    <div class="title">Home Pod</div>
                    <div class="des">
                        Altavoz inteligente compacto de Apple que combina un sonido de alta calidad con la potencia de Siri, el asistente virtual de Apple, en un diseño pequeño y elegante. 
                    </div>
                    <div class="specifications">
                        <div>
                            <p>Tiempo de uso</p>
                            <p>20 horas</p>
                        </div>
                        <div>
                            <p>Puerto de Carga</p>
                            <p>USB-C</p>
                        </div>
                        <div>
                            <p>Compatible</p>
                            <p>iPhone, iPad, Mac, Apple Watch, Apple TV, AirPlay</p>
                        </div>
                        <div>
                            <p>Diseño</p>
                            <p>Diseño elegante y compacto, caracterizado por su forma esférica</p>
                        </div>
                        <div>
                            <p>Precio</p>
                            <p>$2,299.00</p>
                        </div>
                    </div>
                    <a href ="otro.php">
                    <button class="seeAll" id="back">VER TODO  ↗️</button>
                </a>
                <a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
                </div>
            </div>
    </div>

    <div class="arrows">
        <button id="prev"><</button>
        <button id="next">></button>
        
    </div>
</div>
<script src="acces.js"></script>
<footer class="footer">
        <div class="row">
            <div class="footer-col">
                <h4>Andrea Tavizon Torres</h4>
                <ul>
                    <li><a href="#">22308051281103</a></li>
                    <li><a href="contacto.php">Contáctanos</a></li>
                </ul>
        </div>
    </div>
</footer>
</body>
</html>
