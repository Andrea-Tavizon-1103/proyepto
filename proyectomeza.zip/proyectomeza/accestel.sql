-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-11-2024 a las 02:35:12
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `accestel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `orden` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `fecha_agregado` datetime DEFAULT current_timestamp(),
  `imagen` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `categoria`, `fecha_agregado`, `imagen`) VALUES
(1, 'Airpods Pro (2da Generación)', 'Audio Adaptativo que regula el control de ruido según tu entorno y formas inteligentes de minimizar tu exposición a ruidos fuertes.', 5799.00, 'Audicion', '2024-11-21 00:00:00', 'img/airpods.png'),
(2, 'AirPods 4', 'Sonido inmersivo, como en un teatro. El audio espacial personalizado con seguimiento dinámico de cabeza', 2999.00, 'Audicion', '2024-02-28 14:58:38', 'img/airpods4.png'),
(3, 'AirPods Max', 'Cancelacion Activa de Ruido nivel pro. Ecualización adaptativa', 12999.00, 'Audicion', '2022-03-02 14:58:38', 'img/airpodsmax.png'),
(4, 'Cargador MagSafe (2 m)', 'La carga inalámbrica nunca fue tan fácil. El cargador MagSafe se conecta a tu iPhone a través de imanes que se alinean a la perfección para brindarte una carga inalámbrica más rápida', 1299.00, 'carga', '2024-11-21 00:00:00', 'img/c22.png'),
(5, 'Cargador MagSafe (1 m)', 'Cargas inalámbricas rápidas de hasta 15 W con MagSafe para el iPhone 12 o posterior al usar un adaptador de corriente USB‑C de 20 W', 999.00, 'carga', '2024-11-20 14:58:38', 'img/c1.png'),
(6, 'Cable de carga USB-C de 240 W (2 m)', 'Este cable de carga de 2 metros tiene un diseño trenzado y conectores USB-C en ambos extremos. Es ideal para cargar, sincronizar y transferir datos entre dispositivos USB-C.', 749.00, 'carga', '2022-03-02 14:58:38', 'img/c3.png'),
(7, 'Funda Lumen Series con MagSafe de OtterBox - Rosa', 'Esta funda delgada y elegante deja ver la belleza de tu iPhone. La funda Lumen Series se desliza fácilmente en el bolsillo y está especialmente diseñada para interactuar con el ecosistema MagSafe de Apple.', 1099.00, 'proteccion', '2024-11-21 00:00:00', 'img/f1.png'),
(8, 'Funda de silicón con MagSafe - Color ciprés', 'La funda de silicón con MagSafe, diseñada por Apple , es una alternativa ideal de protección.', 1099.00, 'proteccion', '2024-02-28 14:58:38', 'img/f2.png'),
(9, 'Funda transparente con MagSafe', 'Está hecha con una combinación de policarbonato transparente y material flexible que se adapta perfectamente a los botones.', 1099.00, 'proteccion', '2022-03-02 14:58:38', 'img/f7.png'),
(10, 'HomePod mini', 'Impresiona por su tamaño y por su sonido.\r\nControlador de rango completo.\r\nDos radiadores pasivos con cancelación de fuerza.', 2299.00, 'bocina', '2024-11-23 11:50:35', 'img/o8.png'),
(11, 'AirPods 2da Generación', 'Los AirPods brindan una experiencia inalámbrica inigualable: desde una configuración sencilla hasta un audio de alta calidad', 1999.00, 'Audicion', '2024-11-23 12:24:01', 'img/a2.webp'),
(12, 'AirPods 3ra Generación', 'Ajuste perfecto y comodidad excepcional durante todo el día, una experiencia de audio totalmente renovada y Cancelación Activa de Ruido opcional.', 3200.00, 'Audicion', '2024-11-23 12:24:01', 'img/audi3.jpeg'),
(13, 'EarPods con conector Lightning', 'A diferencia de los audífonos circulares tradicionales, el diseño de los EarPods está definido por la geometría del oído. Esto los hace más cómodos de usar que cualquier otro audífono similar.', 549.00, 'Audicion', '2024-11-23 12:34:42', 'img/ear.jpeg'),
(14, 'Almohadillas para los AirPods Max', 'Almohadillas de repuesto para los AirPods Max.', 1799.00, 'Audicion', '2024-11-23 12:39:37', 'img/alm.jpeg'),
(15, 'Almohadillas para los AirPods Pro (segunda generación) — 2 pares (medianas)', 'Almohadillas de reemplazo, compatibles sólo con los AirPods Pro (segunda generación).', 229.00, 'Audicion', '2024-11-23 12:39:37', 'img/alm2.jpeg'),
(16, 'Almohadillas para los AirPods Pro 2 - 4 pares', 'Paquete con varias almohadillas de silicón compatibles con los AirPods Pro 2, en cuatro diferentes tamaños(XS, S, M, G). Elige el par que mejor se acomode a tus oídos para disfrutar de un sonido óptimo.', 299.00, 'Audicion', '2024-11-23 12:43:13', 'img/alm3.jpeg'),
(17, 'Adaptador de corriente USB-C de 20 W', 'El adaptador de corriente USB-C de 20 W de Apple te permite cargar tu dispositivo de manera rápida y eficiente en cualquier lugar.', 549.00, 'Carga', '2024-11-23 12:55:03', 'img/c4.png'),
(18, 'Base de carga magnética 3 en 1 BoostCharge Pro de Belkin', 'La base de carga magnética 3 en 1 BoostCharge Pro de Belkin tiene un cargador magnético Qi2, otro cargador magnético con brazo de inclinación ajustable para el iPhone y otro cargador directamente en la base inferior, que es pequeña pero firme.', 4999.00, 'carga', '2024-11-23 12:55:03', 'img/c8.png'),
(19, 'Cargador Tipo C- lightning', 'Compacto y ligero para facilitar el transporte.', 549.00, 'Carga', '2024-11-23 13:08:23', 'img/carg.png'),
(20, 'Adaptador de corriente compacto de 35 W con dos puertos USB-C', 'El adaptador de corriente compacto de 35 W con dos puertos USB-C te permite cargar dos dispositivos al mismo tiempo dondequiera que estés', 1449.00, 'carga', '2024-11-23 13:08:23', 'img/c7.png'),
(21, 'Base de carga 2 en 1 de OtterBox con MagSafe', 'La base de carga 2 en 1 de OtterBox con MagSafe es de ángulo ajustable y puedes cargar tus AirPods mientras usas tu iPhone', 4.00, 'Carga', '2024-11-23 13:12:49', 'img/c10.png'),
(22, 'Base de carga inalámbrica 2 en 1 con MagSafe', ' Es una solución cómoda que carga tu nuevo iPhone a hasta 15 W con la mayor velocidad disponible.', 3599.00, 'carga', '2024-11-23 13:12:49', 'img/c9.png'),
(23, 'Funda transparente con MagSafe', 'Está hecha con una combinación de policarbonato transparente y material flexible que se adapta perfectamente a los botones. Además, funciona a la perfección con Control de la Cámara, puesto que tiene una cobertura de zafiro con una capa conductora que transmite los movimientos del dedo.', 1099.00, 'proteccion', '2024-11-23 13:22:40', 'img/fundatrans.png'),
(24, 'Funda transparente con MagSafe', 'Está hecha con una combinación de policarbonato transparente y material flexible que se adapta perfectamente a los botones. Además, funciona a la perfección con Control de la Cámara, puesto que tiene una cobertura de zafiro con una capa conductora que transmite los movimientos del dedo.', 1099.00, 'proteccion', '2024-11-23 13:22:40', 'img/fundatransnegra.png'),
(25, 'Funda con MagSafe de Beats', 'La funda con MagSafe de Beats para el iPhone está diseñada para proteger tu dispositivo contra rayones y caídas, y se sometió a muchas horas de prueba durante el proceso de diseño y fabricación. ', 1099.00, 'proteccion', '2024-11-23 13:30:08', 'img/fundamagsafe.png'),
(26, 'Funda Figura Series de OtterBox con MagSafe', 'La funda Figura Series es delgada y está diseñada especialmente para interactuar con la línea de accesorios MagSafe de Apple. Protege a tu iPhone y demuestra tu lado artístico. El perfil ultradelgado se desliza fácilmente en los bolsillos y la funda de una sola pieza es muy fácil de usar.', 1299.00, 'proteccion', '2024-11-23 13:30:08', 'img/f6.png'),
(27, 'Funda de silicón -Color medianoche', 'El elegante acabado exterior de silicón se siente muy cómodo en tu mano y su suave interior de microfibra brinda aún más protección.', 1099.00, 'proteccion', '2024-11-23 14:04:16', 'img/f11.jpeg'),
(28, 'Funda de silicón - Color menta claro', 'El elegante acabado exterior de silicón se siente muy cómodo en tu mano y su suave interior de microfibra brinda aún más protección.', 1099.00, 'proteccion', '2024-11-23 14:04:16', 'img/f12.png'),
(29, 'Protector de privacidad de pantalla UltraGlass ', 'El protector de pantalla UltraGlass de Belkin, con tecnología alemana, encabeza la nueva generación de protección para la pantalla del iPhone. Su avanzado filtro de privacidad bidireccional te ayuda a proteger lo más importante en todo momento. Puedes poner la pantalla en vertical para proteger tu información y en horizontal cuando quieras compartir el contenido.', 779.00, 'proteccion', '2024-11-23 14:05:42', 'img/f13.jpeg'),
(30, 'Protector de pantalla Amplify Glass Glare Guard', 'El protector de pantalla antirreflejo Amplify Glass Glare Guard, diseñado específicamente para el iPhone, protege la pantalla contra caídas, rayones y rasguños. Gracias a sus avanzadas propiedades antirreflejo, la pantalla conserva una excelente visibilidad en todas las condiciones de iluminación, en especial en los entornos más luminosos. Además, le da un respiro a la batería, ya que te permite bajar el brillo de la pantalla sin perder claridad visual.', 1099.00, 'proteccion', '2024-11-23 14:08:38', 'img/f14.jpeg'),
(31, 'Protector de pantalla antirreflejo', 'El protector de pantalla antirreflejo de Belkin brinda máxima protección y visibilidad para la pantalla de tu iPhone. Al reducir los reflejos intensos tanto de la luz del sol como de la luz artificial, te permite ver la pantalla de manera más cómoda incluso en entornos luminosos.', 529.00, 'proteccion', '2024-11-23 14:08:38', 'img/f15.jpeg'),
(32, 'Correa estilo milanés color natural para caja de 46 mm - M/L', 'Una interpretación moderna de un diseño creado en Milán a finales del siglo XIX. Tejida en máquinas italianas especializadas, la suave malla de acero inoxidable de la correa estilo milanés se adapta muy bien a tu muñeca.', 2349.00, 'reloj', '2024-11-23 14:25:05', 'img/o12.png'),
(33, 'Apple Watch Series 10', 'Notificaciones de frecuencia cardiaca alta y baja.\r\nNotificaciones de ritmo irregular.\r\nNotificaciones de capacidad aeróbica baja.', 9499.00, 'reloj', '2024-11-23 14:25:05', 'img/o19.jpeg'),
(34, 'Correa uniloop trenzada verde chartreuse para caja de 46 mm ', 'Gracias a su diseño elástico único, las correas uniloop trenzadas son muy cómodas y fáciles de poner y quitar. Están fabricadas con 16,000 filamentos de poliéster reciclado trenzados con hilos de silicón ultrafinos usando maquinaria avanzada para crear un trenzado preciso.', 2349.00, 'reloj', '2024-11-23 14:29:31', 'img/o17.png'),
(35, 'Correa loop deportiva color ciruela para caja de 46 mm', 'La correa loop deportiva es suave, ligera y transpirable, y tiene un cierre adhesivo ajustable. El tejido de nylon de doble capa tiene una trama compacta en la parte que está en contacto con la piel, lo que brinda más comodidad y evita que se acumule la humedad.', 1099.00, 'reloj', '2024-11-23 14:29:31', 'img/o15.png'),
(36, 'Correa deportiva azul denim para caja de 46 mm - M/L', 'La correa deportiva está hecha de fluoroelastómero de alto rendimiento. Es duradera, resistente y sorprendentemente suave.', 1099.00, 'reloj', '2024-11-23 14:32:57', 'img/o16.png'),
(37, 'Smart Folio para el iPad mini (A17 Pro) - Color salvia', 'La funda Smart Folio para el iPad mini es ligera y delgada y protege tu dispositivo por ambos lados. Esta funda activa el iPad cuando la abres y lo pone en reposo cuando la cierras. Se adhiere magnéticamente y puedes plegarla fácilmente en diferentes posiciones para crear una base que te permite leer, ver videos, escribir o hacer llamadas de FaceTime.', 1299.00, 'tablet', '2024-11-23 14:32:57', 'img/o14.png'),
(38, 'Apple Pencil Pro', 'El Apple Pencil Pro suma aún más funcionalidades para ayudarte a crear lo que imagines. Con estos avances, puedes marcar documentos, tomar notas y crear obras maestras de forma más intuitiva.', 2999.00, 'tablet', '2024-11-23 14:35:56', 'img/o13.jpeg'),
(39, 'Apple TV 4K', 'El Apple TV 4K (3.ª generación) es un paquete de entretenimiento completo que combina lo mejor de la TV con tus dispositivos y servicios de Apple favoritos. Y ahora también incluye FaceTime para hacer llamadas directo en tu televisión.Nota al pie', 3199.00, 'tv', '2024-11-23 14:35:56', 'img/o1.png'),
(40, 'AirTag', 'Ponles un AirTag a tus llaves o a tu mochila. Si se te pierde algo, con la app Encontrar sabrás dónde está. ', 649.00, 'ubicacion', '2024-11-23 14:40:13', 'img/o3.png'),
(41, 'AirTag (4 Piezas)', 'Puedes compartir tu AirTag con hasta cinco personas, para que no pierdan de vista las cosas que usan entre todos.', 2199.00, 'ubicacion', '2024-11-23 14:40:13', 'img/o2.png'),
(42, 'Llavero de FineWoven para el AirTag – Color zarzamora', 'El llavero de FineWoven está cuidadosamente hecho con innovadores materiales. El acero inoxidable es tan resistente como elegante, mientras que el microtwill, resistente y suave como la gamuza', 749.00, 'ubicacion', '2024-11-23 14:43:30', 'img/o11.png'),
(43, 'Cartera magnética con soporte de Satechi, compatible con MagSafe', 'La cartera magnética con soporte de Satechi combina a la perfección el estilo, la funcionalidad y la sustentabilidad. Es un accesorio imprescindible y el compañero perfecto para tus necesidades cotidianas.', 1199.00, 'tarjetero', '2024-11-23 14:43:30', 'img/o4.png'),
(44, 'Cartera de FineWoven con MagSafe para el iPhone – Azul intenso', 'La nueva cartera de FineWoven con MagSafe para el iPhone es la manera más práctica y elegante de tener tus tarjetas a la mano.', 1399.00, 'tarjetero', '2024-11-23 14:44:54', 'img/tarj.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
