<?php
session_start();
include('db.php'); // Conexión a la base de datos

// Ejecutar la consulta SQL para obtener los productos
$resultado = $db->query("SELECT * FROM productos");

// Verificar si la consulta fue exitosa
if ($resultado) {
    $productos = []; // Inicializar el array de productos
    while ($producto = $resultado->fetch_object()) {
        // Agregar cada producto al array
        $productos[] = $producto;
    }
    // Liberar el resultado de la consulta
    $resultado->close();
} else {
    echo "Error en la consulta: " . $db->error;
}
?>

<div class="container mt-5">
    <h1 class="text-center text-primary">Listado de Productos</h1>
    <div class="mb-3 text-right">
    <a class="btn btn-success" href="formulario.php">Nuevo Producto</a>
</div>

    <table class="table table-striped table-bordered table-center">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Categoría</th>
                <th>Fecha Agregado</th>
                <th>Imagen</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Verificar si la variable $productos está definida y contiene elementos
            if (isset($productos) && !empty($productos)) {
                foreach($productos as $producto) { 
                    // Verificar si la propiedad existe antes de mostrarla
            ?>
                    <tr>
                        <td><?php echo isset($producto->id) ? $producto->id : 'No disponible'; ?></td>
                        <td><?php echo isset($producto->nombre) ? $producto->nombre : 'No disponible'; ?></td>
                        <td><?php echo isset($producto->descripcion) ? $producto->descripcion : 'No disponible'; ?></td>
                        <td><?php echo isset($producto->precio) ? "$" . number_format($producto->precio, 2) : 'No disponible'; ?></td>
                        <td><?php echo isset($producto->categoria) ? $producto->categoria : 'No disponible'; ?></td>
                        <td><?php echo isset($producto->fecha_agregado) ? date("d/m/Y", strtotime($producto->fecha_agregado)) : 'No disponible'; ?></td>
                        <td><img src="<?php echo isset($producto->imagen) ? $producto->imagen : 'default.jpg'; ?>" width="100" height="100" alt="Producto"></td>
                        <td><a class="btn btn-warning" href="editar.php?id=<?php echo $producto->id; ?>"><i class="fa fa-edit"></i></a></td>
                        <td><a class="btn btn-danger" href="eliminar.php?id=<?php echo $producto->id; ?>"><i class="fa fa-trash"></i></a></td>
                    </tr>
                <?php }
            } else { ?>
                <tr>
                    <td colspan="10" class="text-center">No hay productos disponibles.</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<a href="index.php">
    <button class="seeAll" id="home">REGRESAR AL INICIO ↩️</button>
</a>
