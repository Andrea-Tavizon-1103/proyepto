<?php
session_start();

// Verificar si el usuario está logueado y tiene el rol de admin
if (!isset($_SESSION['login_user']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: iniciosesion_admin.php"); // Redirigir al login si no es admin
    exit();
}

// Código para mostrar el panel de administración
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
</head>
<body>
    <h1>Bienvenido al Panel de Administración</h1>
    <p>Desde aquí puedes gestionar los productos, usuarios y más.</p>
    <a href="listar.php">Ver productos</a>
    <a href="logout.php">Cerrar sesión</a>
</body>
</html>
