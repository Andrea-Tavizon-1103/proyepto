<?php
# Verifica que se enviaron todos los datos
if (
    !isset($_POST["ID_Productos"], $_POST["name"], $_POST["description"], $_POST["price"])
) {
    echo "Todos los campos son obligatorios.";
    exit();
}

$ID_Producto = $_POST["ID_Productos"];
$name = $_POST["name"];
$description = $_POST["description"];
$price = $_POST["price"];

include_once "db.php";

// Manejo de la imagen
$imagenPath = ""; // Inicializamos la ruta de la imagen

if ($_FILES["imagen"]["size"] > 0) {
    $imagen = $_FILES["imagen"];
    $imagenName = $imagen["name"];
    $imagenTmpName = $imagen["tmp_name"];

    // Crear directorio si no existe
    $uploadDir = "imagenes/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $imagenPath = $uploadDir . basename($imagenName);

    // Mover la imagen al directorio
    if (!move_uploaded_file($imagenTmpName, $imagenPath)) {
        echo "Error al cargar la imagen.";
        exit();
    }
} else {
    // Recuperar la imagen actual
    $query = "SELECT Imagen FROM productos WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $ID_Producto);
    $stmt->execute();
    $stmt->bind_result($currentImage);
    $stmt->fetch();
    $stmt->close();
    $imagenPath = $currentImage; // Usamos la imagen actual si no se sube una nueva
}

// Preparar la consulta SQL
$query = "UPDATE productos SET Nombre = ?, Descripcion = ?, Precio = ?, Imagen = ? WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->bind_param("ssdsi", $name, $description, $price, $imagenPath, $ID_Producto);

if ($stmt->execute()) {
    header("Location: listar.php");
    exit;
} else {
    echo "Error al actualizar el producto: (" . $stmt->errno . ") " . $stmt->error;
}

$stmt->close();
?>
