<?php
// Conectar a la base de datos
$conn = new mysqli('localhost', 'root', '', 'accestel');

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consultar empleados
$sql_empleados = "SELECT * FROM empleados";
$resultado_empleados = $conn->query($sql_empleados);

// Consultar proveedores
$sql_proveedores = "SELECT * FROM proveedores";
$resultado_proveedores = $conn->query($sql_proveedores);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccesTel</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="styletar.css">
</head>
<body>

<header>
    <nav>
        <div class="logo">
            <a href="index.php">
                <img src="img/apple.png" height="50" alt="Logo de AccesTel">
            </a>
        </div>
        <nav class="navbar">
            <div class="container">
                <div class="navbar-header"></div>

                <div class="navbar-menu" id="open-navbar1">
                    <ul class="navbar-nav">
                        <li class="active"><a href="index.php">Inicio</a></li>
                        <li class="navbar-dropdown">
                            <a href="#" class="dropdown-toggler" data-dropdown="my-dropdown-id">
                                Categorias <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown" id="my-dropdown-id">
                                <li><a href="audi.php">Audifonos</a></li>
                                <li><a href="carga.php">Cargadores</a></li>
                                <li><a href="fundas.php">Fundas</a></li>
                                <li><a href="otro.php">Otros</a></li>
                            </ul>
                        </li>
                        <li><a href="contacto.php">Contacto</a></li>
                        <a href="cart.php">
                            <img src="img/bolsa.png" alt="Carrito de compras" height="35">
                        </a>
                    </ul>
                </div>
            </div>
        </nav>
    </nav>            
</header>

<div class="container">
    <center><h1>Listado de Empleados</h1></center>
    <?php
    // Verificar si hay empleados
    if ($resultado_empleados->num_rows > 0) {
        echo "<div class='card-container'>"; // Contenedor de las tarjetas
        while ($empleado = $resultado_empleados->fetch_assoc()) {
            echo "<div class='card'>
                    <div class='card-body'>
                        <h3 class='card-title'>" . $empleado['nombre'] . " " . $empleado['apellido'] . "</h3>
                        <p class='card-text'>Correo: " . $empleado['correo'] . "</p>
                        <p class='card-text'>Teléfono: " . $empleado['telefono'] . "</p>
                        <p class='card-text'>Puesto: " . $empleado['puesto'] . "</p>
                        <p class='card-text'>Fecha de Ingreso: " . $empleado['fecha_ingreso'] . "</p>
                    </div>
                </div>";
        }
        echo "</div>"; // Cerrar el contenedor de las tarjetas de empleados
    } else {
        echo "No hay empleados disponibles.";
    }
    ?>

    <center><h1>Listado de Proveedores</h1></center>
    <?php
    // Verificar si hay proveedores
    if ($resultado_proveedores->num_rows > 0) {
        echo "<div class='card-container'>"; // Contenedor de las tarjetas de proveedores
        while ($proveedor = $resultado_proveedores->fetch_assoc()) {
            echo "<div class='card'>
                    <div class='card-body'>
                        <h3 class='card-title'>" . $proveedor['nombre'] . "</h3>
                        <p class='card-text'>Contacto: " . $proveedor['contacto'] . "</p>
                        <p class='card-text'>Teléfono: " . $proveedor['telefono'] . "</p>
                        <p class='card-text'>Correo: " . $proveedor['correo'] . "</p>
                        <p class='card-text'>Dirección: " . $proveedor['direccion'] . "</p>
                        <p class='card-text'>Fecha de Registro: " . $proveedor['fecha_registro'] . "</p>
                    </div>
                </div>";
        }
        echo "</div>"; // Cerrar el contenedor de las tarjetas de proveedores
    } else {
        echo "No hay proveedores disponibles.";
    }
    ?>

</div>

</body>
</html>

<?php
// Cerrar la conexión
$conn->close();
?>



    </div>
</body>
</html>
