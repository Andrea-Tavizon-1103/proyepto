<?php
session_start();

// Obtener la fecha actual
$fecha = date("d/m/Y");

// Inicializar variables para el total y el subtotal
$total = 0;
$subTotal = 0;

// Crear el encabezado del ticket
$ticket = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Ticket de Compra</title>
    <link rel='stylesheet' type='text/css' href='styleT.css'>
</head>
<body>

    <div class='ticket-container'>
        <div class='abc'>
            <img src='img/apple.png'>
            <h2>AccesTel</h2>
        </div>
        <div class='eslogan'>
            <h4>'Tu vida en un lugar'</h4>
        </div>

        <h1>Ticket de Compra</h1>
        <p>Fecha: $fecha</p>
        <table>
            <tr>
                <th>Producto</th>
                <th>Precio Unitario</th>
                <th>Cantidad</th>
                <th>Total</th>
            </tr>";

foreach ($_SESSION['cart'] as $item) {
    $totalProducto = $item['price'] * $item['quantity'];
    $subTotal += $totalProducto;
    $ticket .= "
            <tr>
                <td>{$item['name']}</td>
                <td>\${$item['price']}</td>
                <td>{$item['quantity']}</td>
                <td>\$$totalProducto</td>
            </tr>";
}

$iva = $subTotal * 0.16;

$totalConIva = $subTotal + $iva;

$ticket .= "
            <tr>
                <td colspan='3'><strong>Subtotal</strong></td>
                <td>\$$subTotal</td>
            </tr>";

$ticket .= "
            <tr>
                <td colspan='3'><strong>IVA (16%)</strong></td>
                <td>\$$iva</td>
            </tr>";

$ticket .= "
            <tr>
                <td colspan='3'><strong>Total</strong></td>
                <td>\$$totalConIva</td>
            </tr>
        </table>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div style='text-align: center;'>
        <a href='catalogo.php' class='button'>Regresar al inicio</a>
    </div>
    <footer>
        <p>'Tu vida en un lugar'<br> Andrea Tavizon Torres <br> 22308051281103</p>
    </footer>
</body>
</html>";

echo $ticket;
?>