<?php
session_start();
include('db.php'); // Conexión a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Procesar inicio de sesión
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prevenir SQL Injection
    $username = $db->real_escape_string($username);
    $password = $db->real_escape_string($password);

    // Buscar el usuario en la base de datos
    $sql = "SELECT id, usuario, contrasena, role FROM admins WHERE usuario='$username'";
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verificar la contraseña usando password_verify() (si se ha encriptado previamente)
        if (password_verify($password, $row['contrasena'])) {
            $_SESSION['login_user'] = $row['usuario']; // Guardar el usuario en la sesión
            $_SESSION['user_role'] = $row['role']; // Guardar el rol del usuario

            header("Location: admin_dashboard.php"); // Redirigir al panel de administración
            exit();
        } else {
            $error_message = "Contraseña inválida.";
        }
    } else {
        $error_message = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="iniciosesion_admin.php">
        <h2>Iniciar Sesión como Administrador</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Iniciar Sesión</button>
        <p class="message">¿No tienes cuenta? <a href="iniciosesion.php">Iniciar sesión como usuario</a></p>
        
        <?php if (isset($error_message)): ?>
            <p style="color: red; font-weight: bold;"><?php echo $error_message; ?></p>
        <?php endif; ?>
    </form>
</body>
</html>
