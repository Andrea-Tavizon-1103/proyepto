<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['login_user'])) {
    echo "Error: Debe iniciar sesión para agregar productos al carrito.";
    exit();
}

// Obtener datos enviados por el formulario
$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$quantity = 1;

// Crear el carrito si no existe
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Agregar producto al carrito
$exists = false;
foreach ($_SESSION['cart'] as &$item) {
    if ($item['id'] == $id) {
        $item['quantity'] += $quantity; // Incrementar cantidad
        $exists = true;
        break;
    }
}

if (!$exists) {
    $_SESSION['cart'][] = ['id' => $id, 'name' => $name, 'price' => $price, 'quantity' => $quantity];
}

// Redirigir al carrito
header("Location: cart_view.php");
exit();
?>
