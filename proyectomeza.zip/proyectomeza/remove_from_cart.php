<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['index'])) {
    $index = $_GET['index'];

    if (isset($_SESSION['cart']) && isset($_SESSION['cart'][$index])) {
        unset($_SESSION['cart'][$index]); // Eliminar el producto del carrito
    }
}

header("Location: cart_view.php"); // Redirigir de vuelta a la vista del carrito
exit();
?>