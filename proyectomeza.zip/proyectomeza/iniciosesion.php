<?php
session_start();
include('db.php'); // Conexión a la base de datos

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recoger los datos del formulario
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];  // Obtener el tipo de usuario (admin o user)

    // Depuración: Imprimir los valores de $_POST
    echo '<pre>';
    print_r($_POST); // Imprime los datos recibidos
    echo '</pre>';

    // Prevenir SQL Injection
    $username = $db->real_escape_string($username);
    $password = $db->real_escape_string($password);

    // Dependiendo del rol seleccionado (admin o user), realizar la consulta
    if ($role == 'admin') {
        $sql = "SELECT id, usuario, contrasena, role FROM admins WHERE usuario='$username'";
    } else {
        $sql = "SELECT id, usuario, contrasena, role FROM usuarios WHERE usuario='$username'";
    }

    // Depuración: Verificar la consulta SQL generada
    echo "Consulta SQL: $sql";

    // Ejecutar la consulta
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verificar la contraseña utilizando password_verify() para contraseñas encriptadas
        if ($password === $row['contrasena']) {
            $_SESSION['login_user'] = $row['usuario']; // Guardar el usuario en la sesión
            $_SESSION['user_role'] = $row['role'];     // Guardar el rol del usuario
        
            // Redirigir dependiendo del rol
            if ($row['role'] == 'admin') {
                header("Location: admin_dashboard.php"); // Redirigir al panel de administración
            } else {
                header("Location: index.php"); // Redirigir al sitio principal
            }
            exit();
        } else {
            $error_message = "Contraseña inválida.";
        }
    }
}        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="iniciosesion.php">
        <h2>Iniciar Sesión</h2>
        
        <!-- Campo para nombre de usuario -->
        <input type="text" name="username" placeholder="Nombre de Usuario" required>
        
        <!-- Campo para contraseña -->
        <input type="password" name="password" placeholder="Contraseña" required>
        
        <!-- Selección del tipo de usuario -->
        <label for="role">Iniciar sesión como:</label>
        <select name="role" required>
            <option value="admin">Administrador</option>
            <option value="user">Usuario</option>
        </select>

        <!-- Botón para enviar el formulario -->
        <button type="submit">Iniciar Sesión</button>
        
        <!-- Enlace para iniciar sesión como usuario -->
        <p class="message">¿No tienes cuenta? <a href="Registrarse.php">Regístrate</a></p>

        <?php if (isset($error_message)): ?>
            <p style="color: red; font-weight: bold;"><?php echo $error_message; ?></p>
        <?php endif; ?>
    </form>
</body>
</html>
